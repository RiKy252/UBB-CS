#include <iostream>
#include <thread>
#include <mutex>

std::mutex mtx;

void critical_section(int& id) {
    // std::lock_guard<std::mutex> lock(mtx);
    std::cout << "Thread-" << id << " entering critical section" << std::endl;
    id +=3;
    std::cout << "Thread-" << id << " leaving critical section" << std::endl;
}


int main() {
    int id = 2;
    std::thread t1(critical_section, std::ref(id));
    std::thread t2(critical_section, std::ref(id));
    t1.join();
    t2.join();
    return 0;
}
