package lab1.synchronization;

public interface Counter {
    void incrementCount();
    int getCount();
    void setCount(int count);
}
