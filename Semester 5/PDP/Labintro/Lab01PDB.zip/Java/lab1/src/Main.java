import counter.*;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class Main {

    private static void run(List<Thread> threads) {
        long startTime = System.currentTimeMillis();
        // start all threads
        for (Thread thread : threads) {
            thread.start();
        }
        // wait for all threads to finish
        for (Thread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                throw  new RuntimeException(e);
            }
        }
        long endTime = System.currentTimeMillis();
        System.out.println("Processing time: " + (endTime - startTime) + " ms");
    }
    
    private static List<Thread> createThreads(int numberOfThreads, Runnable task) {
        List<Thread> threads = new ArrayList<>();
        for (int i = 0; i < numberOfThreads; i++) {
            threads.add(new Thread(task));
        }
        return threads;
    }
    
    private static void runWrong() {
        Counter counter = new WrongCounter();
        List<Thread> threads = createThreads(1000, counter::incrementCount);
        run(threads);
        System.out.println("Expected count: " + threads.size() + ", Actual count: " + counter.getCount());
    }

    private static void runWrongWithDebug() {
        Counter counter = new WrongCounter().withDebug();
        List<Thread> threads = createThreads(2, counter::incrementCount);
        run(threads);
        System.out.println("Expected count: " + threads.size() + ", Actual count: " + counter.getCount());
    }

    private static void runAtomicVars() {
        Counter counter = new AtomicVarCounter();
        List<Thread> threads = createThreads(1000, counter::incrementCount);
        run(threads);
        System.out.println("Expected count: " + threads.size() + ", Actual count: " + counter.getCount());
    }

    private static void runSynchronized() {
        Counter counter = new SynchronizedCounter();
        List<Thread> threads = createThreads(1000, counter::incrementCount);
        run(threads);
        System.out.println("Expected count: " + threads.size() + ", Actual count: " + counter.getCount());
    }

    private static void runGranularSynchronized() {
        Counter counter = new GranularSynchronizedCounter();
        List<Thread> threads = createThreads(1000, counter::incrementCount);
        run(threads);
        System.out.println("Expected count: " + threads.size() + ", Actual count: " + counter.getCount());
    }

    private static void runReentrantSynchronized() {
        Counter counter = new ReentrantSynchronizedCounter();
        List<Thread> threads = createThreads(1000, counter::incrementCount);
        run(threads);
        System.out.println("Expected count: " + threads.size() + ", Actual count: " + counter.getCount());
    }

    private static void runExclusiveLock() {
        Counter counter = new SynchronizedCounter();
        List<Thread> readers = createThreads(1000, counter::getCount);
        List<Thread> writers = createThreads(1000, counter::incrementCount);
        run(Stream.concat(readers.stream(), writers.stream()).toList());
        System.out.println("Expected count: " + readers.size() + ", Actual count: " + counter.getCount());
    }

    private static void runSharedLock() {
        Counter counter = new SharedLockCounter();
        List<Thread> readers = createThreads(1000, counter::getCount);
        List<Thread> writers = createThreads(1000, counter::incrementCount);
        run(Stream.concat(readers.stream(), writers.stream()).toList());
        System.out.println("Expected count: " + readers.size() + ", Actual count: " + counter.getCount());
    }

    public static void main(String[] args) {
        // 1. un-predictable/wrong result due to concurrency
        //runWrong();
        //runWrongWithDebug();

        // 2. correct result

        // 2.1. atomic variables
        //runAtomicVars();

        // 2.2. synchronized
        //runSynchronized();

        // see also: ReentrantLock, Semaphore, CountDownLatch etc.

        // 2.3. synchronized with finer granularity improves performance
        //runGranularSynchronized();

        // 2.4. The lock behind the synchronized methods and blocks is reentrant (recursive)
        //runReentrantSynchronized();

        // 2.5. Finer granularity using shared locks => improved performance
        runExclusiveLock();
        runSharedLock();
    }
}