package counter;

public class WrongCounter extends AbstractCounter {

    @Override
    public void incrementCount() {
        int count = getCount();
        simulateMoreProcessingTime(1L);
        setCount(count + 1);
    }
}
