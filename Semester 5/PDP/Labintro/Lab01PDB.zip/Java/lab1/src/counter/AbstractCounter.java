package counter;

public abstract class AbstractCounter implements Counter {
    protected int count = 0;
    protected boolean debug = false;

    @Override
    public int getCount() {
        if (debug) {
            System.out.println(Thread.currentThread().getName() + " - reading count (count=" + count + ")");
        }
        return count;
    }

    @Override
    public void setCount(int count) {
        if (debug) {
            System.out.println(Thread.currentThread().getName() + " - writing count (count=" + count + ")");
        }
        this.count = count;
    }

    protected void simulateMoreProcessingTime(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    public Counter withDebug() {
        debug = true;
        return this;
    }
}
