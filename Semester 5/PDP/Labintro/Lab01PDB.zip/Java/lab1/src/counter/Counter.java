package counter;

public interface Counter {
    void incrementCount();
    int getCount();
    void setCount(int count);
}
